import React, { Component } from 'react';
export class PublicPage extends Component {
    state = {}
    render() {
        return (<div>
            haha
        </div>);
    }
}

export default PublicPage;