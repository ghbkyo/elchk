import React, { Component } from 'react';
export class PrivatePage extends Component {
    state = {}
    render() {
        return (<div>
            hoho
        </div>);
    }
}

export default PrivatePage;