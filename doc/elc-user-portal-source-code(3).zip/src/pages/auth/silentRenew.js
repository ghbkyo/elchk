import { loginSilentCallback } from "../../services/AuthService"

const SilentRenewPage = () => {
    loginSilentCallback()
    return <div></div>
}

export default SilentRenewPage